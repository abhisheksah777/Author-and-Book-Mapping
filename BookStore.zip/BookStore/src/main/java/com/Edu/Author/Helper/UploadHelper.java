package com.Edu.Author.Helper;

import java.io.IOException;

import org.springframework.core.io.ClassPathResource;
import org.springframework.web.multipart.MultipartFile;

public class UploadHelper {

	public final String upload_dir = new ClassPathResource("static/image").getFile().getAbsolutePath();

	public UploadHelper() throws IOException {
		
		

	}
	public boolean getUpload(MultipartFile multipartFile) {
		return false;
		
	}
}
