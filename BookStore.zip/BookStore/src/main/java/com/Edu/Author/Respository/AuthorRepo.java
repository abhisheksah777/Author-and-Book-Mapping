package com.Edu.Author.Respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edu.Book.Entity.Author;

public interface AuthorRepo extends JpaRepository<Author, Integer> {

}
