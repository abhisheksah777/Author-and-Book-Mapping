package com.Edu.Book.Respository;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;

import com.Edu.Book.Entity.BookS;

@EnableAutoConfiguration
public interface BookRepository extends JpaRepository<BookS, Integer> {

}
