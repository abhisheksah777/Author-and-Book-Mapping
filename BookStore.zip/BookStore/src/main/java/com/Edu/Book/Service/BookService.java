package com.Edu.Book.Service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Edu.Book.Entity.BookS;
@Service
public interface BookService {
	
	public ResponseEntity<String> insertBook(BookS book);
	public List<BookS> getAllbook();

}
