package com.Edu.Book.Controller;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.servlet.MultipartAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.Edu.Book.Entity.BookS;
import com.Edu.Book.ServiceImpl.BookServcieImpl;

@RestController
@RequestMapping("/book")
public class BookController {
	@Autowired
	private BookServcieImpl bookServcieImpl;

	@GetMapping("/{id}")
	public BookS getBookById(@PathVariable int id) {
		BookS bk = bookServcieImpl.getBooKId(id);
		return bk;
	}

	@GetMapping()
	public List<BookS> getBook() {
		List<BookS> bk = bookServcieImpl.getAllbook();
		return bk;

	}

	@PostMapping()
	public ResponseEntity<String> insertBook(@RequestBody BookS bootdto) {
		this.bookServcieImpl.insertBook(bootdto);
		return ResponseEntity.ok("Data Savad");

	}

	@PostMapping("/upload-file")
	public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
		if (file.isEmpty()) {
			ResponseEntity.ok("File Should Not Empty");

		}
		if(!file.getContentType().contains("JPEG")) {
			ResponseEntity.ok("File Content Type Should be in JPEG Format");
		}
		else {
			
		}
		return null;

	}

}
