package com.Edu.Book.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "Author")
public class Author {
	@Id
	private int authorid;
	private String authorname;
	private String address;
	 @JsonBackReference
	 @ManyToOne()
	 @JoinColumn(name = "bookid")
		private BookS book;
	

}
