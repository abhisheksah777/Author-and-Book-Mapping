package com.Edu.Book.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Edu.Book.Entity.BookS;
import com.Edu.Book.Respository.BookRepository;
import com.Edu.Book.Service.BookService;

@Service
//@RequiredArgsConstructor
public class BookServcieImpl implements BookService {
//	ModelMapper modelMapper;
//	@Autowired
	BookRepository bookRepository;

	public BookServcieImpl(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}

	@Override
	public ResponseEntity<String> insertBook(BookS book) {
//		Book book=modelMapper.map(book, Book.class);
		BookS booksave = bookRepository.save(book);
//		BookDTO bookd=modelMapper.map(booksave, BookDTO.class);
		return ResponseEntity.ok("Saved");
	}

	public BookS getBooKId(Integer id) {
		Optional<Integer> bid = Optional.of(id);
		if (bid.isPresent()) {
		   BookS bk=bookRepository.findById(id).get();
		   return bk;
		}else {
		return (BookS) ResponseEntity.notFound();
		}
		
	}

	@Override
	public List<BookS> getAllbook() {
		return	bookRepository.findAll();
	}

}
